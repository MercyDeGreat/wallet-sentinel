"use strict";exports.id=6244,exports.ids=[6244],exports.modules={26244:(e,l,r)=>{r.r(l),r.d(l,{arrowRightSvg:()=>d});var o=r(37207);let d=(0,o.YP)`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1 7.99a1 1 0 0 1 1-1h7.58L7.12 4.53A1 1 0 1 1 8.54 3.1l4.16 4.17a1 1 0 0 1 0 1.41l-4.16 4.17a1 1 0 1 1-1.42-1.41l2.46-2.46H2a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`}};