"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[766],{50766:function(e,l,n){n.r(l),n.d(l,{chevronBottomSvg:function(){return r}});var o=n(31133);let r=(0,o.YP)`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1.46 4.96a1 1 0 0 1 1.41 0L8 10.09l5.13-5.13a1 1 0 1 1 1.41 1.41l-5.83 5.84a1 1 0 0 1-1.42 0L1.46 6.37a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`}}]);