"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3776],{13776:function(e,l,n){n.r(l),n.d(l,{externalLinkSvg:function(){return a}});var r=n(31133);let a=(0,r.YP)`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.74 3.99a1 1 0 0 1 1-1H11a1 1 0 0 1 1 1v6.26a1 1 0 0 1-2 0V6.4l-6.3 6.3a1 1 0 0 1-1.4-1.42l6.29-6.3H4.74a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`}}]);