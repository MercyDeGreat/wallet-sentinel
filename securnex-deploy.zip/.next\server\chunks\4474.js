"use strict";exports.id=4474,exports.ids=[4474],exports.modules={24474:(e,l,o)=>{o.r(l),o.d(l,{chevronBottomSvg:()=>t});var r=o(37207);let t=(0,r.YP)`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M1.46 4.96a1 1 0 0 1 1.41 0L8 10.09l5.13-5.13a1 1 0 1 1 1.41 1.41l-5.83 5.84a1 1 0 0 1-1.42 0L1.46 6.37a1 1 0 0 1 0-1.41Z"
    clip-rule="evenodd"
  />
</svg>`}};