"use strict";exports.id=7539,exports.ids=[7539],exports.modules={57539:(r,s,e)=>{e.r(s),e.d(s,{cursorSvg:()=>t});var o=e(37207);let t=(0,o.YP)` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`}};